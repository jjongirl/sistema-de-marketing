# Calendário Editorial — o que foi adicionado ao sistema

## Arquivos

| Arquivo | Situação |
|---|---|
| `index.html` | modificado — inserções pontuais, nada foi removido nem reescrito |
| `pautas.json` | **novo** — registro de datas e banco de pautas |

Nenhum outro arquivo foi tocado. `api/`, `firestore.rules`, `package.json` e o resto seguem iguais.

## As seis alterações no index.html

1. **CSS** — bloco `CALENDÁRIO EDITORIAL` acrescentado antes do `</style>`. Todas as classes têm prefixo `ed-`, então não há colisão com o que já existia. As cores saem das variáveis do sistema (`--accent-*`, `--bg-*`, `--text-*`), inclusive no tema claro.
2. **Menu** — item "Calendário Editorial" logo abaixo de "Pauta Operacional", em Operações.
3. **`pageLabels`** — título do topbar.
4. **`renderPage`** — rota `editorial: renderEditorial`.
5. **Seção** — `<section id="page-editorial">` antes do `</main>`, seguindo o mesmo padrão das outras páginas (`section-header`, `stat-grid`, `filter-chip`, `badge`, `empty-state`).
6. **JavaScript** — motor de datas e montagem da grade, no fim do script principal. Tudo dentro do objeto `ED` e de funções com prefixo `ed`, sem mexer em nada que já rodava.

## Como funciona

A página não guarda calendário nenhum. Ela **calcula** a grade no momento em que é aberta, a partir da data do navegador:

- Resolve cada uma das 137 datas do registro para o ano corrente — Páscoa pelo algoritmo de Meeus (Carnaval = −47, Corpus Christi = +60), Dia das Mães como 2º domingo de maio, Black Friday como última sexta de novembro.
- Monta as semanas de segunda a domingo e distribui 3 posts e 2 Reels por semana em cada conta.
- Encaixa as datas comemorativas no dia certo, por ordem de peso comercial. Data que cai em sábado ou domingo é antecipada para a sexta.
- Preenche o que sobra com pautas perenes, em rotação e sem repetir dentro da janela.
- Divide os responsáveis: Reel vai para o Félix, peça de conversão ou impulsionamento vai para a Raquel, o resto para a Mariana.

Abrir em março mostra março. Abrir em 2029 mostra 2029.

## Integrações com o resto do sistema

- **As abas Todos / Click / Impresul** do topo da sidebar filtram a marca, igual às outras páginas — não há um seletor duplicado dentro do calendário.
- **`showToast`** é usado nos avisos de recarga e exportação.
- **Carga sob demanda**: o `pautas.json` só é buscado quando alguém abre a página pela primeira vez. Quem nunca entra no calendário não paga esse download.
- **Exportar CSV** respeita os filtros ativos e sai com BOM, para abrir direto no Excel em português.

## Do calendário para o Kanban

Cada card tem um **`+`** ao lado do responsável. Um clique cria a tarefa na aba Tarefas já preenchida:

| Campo da tarefa | De onde sai |
|---|---|
| Título | formato + título da peça — ex.: `Reel · O azul que some quando vira papel` |
| Descrição | data comemorativa, ideia, gancho, CTA, pilar, recorte e o prazo de produção |
| Data e hora | o dia da peça na grade; 09:00 para Reel, 10:00 para os demais |
| Prioridade | Alta → alta, Média → média, Baixa → baixa. Peça com prazo estourado entra como **urgente** |
| Categoria | Impresul ou Click — cai certo nas abas do topo |
| Responsável | Félix nos Reels, Raquel nas peças de conversão e impulsionamento, Mariana no resto |
| Cor | magenta na Impresul, ciano na Click |
| Etiquetas | formato, pilar, `editorial` e `ads` quando for impulsionar |
| Agenda | marcada, então aparece também no Calendário operacional |

No cabeçalho de cada semana tem **"Mandar semana p/ Tarefas"**, que cria de uma vez todas as peças visíveis daquela semana — respeitando os filtros ativos. Se você filtrar por Reel e por Félix, só vão as peças dele.

**Sem duplicata:** cada tarefa criada guarda uma chave (`edKey`) formada por data, marca e título. O botão de uma peça que já virou tarefa aparece verde com um ✓ e não cria de novo, mesmo depois de recarregar a página ou trocar de aba. O contador ao lado dos filtros mostra quantas das peças visíveis já estão na fila.

As tarefas nascem em **Pendente**, para a equipe puxar no Kanban como qualquer outra.

## De onde vêm os dados (e por que não quebra)

A página tenta ler o `pautas.json` externo primeiro — em `./pautas.json` e depois em `/pautas.json`. Se conseguir, usa ele. Se não conseguir, cai no **banco embutido** dentro do próprio `index.html` e segue funcionando normalmente, só avisando no rodapé em laranja.

Isso cobre os três casos que aparecem na prática:

| Situação | O que acontece |
|---|---|
| Site publicado, com `pautas.json` na raiz | usa o externo — é o modo normal |
| `pautas.json` ainda não subiu no deploy | usa o embutido e avisa no rodapé |
| Alguém abriu o `index.html` clicando no arquivo | o navegador bloqueia `fetch` em `file://`; usa o embutido e avisa que é preciso abrir pelo servidor |

O rodapé do calendário sempre diz qual dos dois está em uso. Se estiver laranja dizendo "banco embutido", clique em **Diagnóstico** no topo da página: ele testa o caminho do arquivo e diz em uma linha o que está errado — arquivo ausente no deploy, rota devolvendo HTML por causa de rewrite, página aberta em `file://`, ou JSON corrompido. Cada caso vem com a correção junto. Se você atualizou o `pautas.json` e o rodapé continua laranja dizendo "banco embutido", o arquivo não está sendo servido — confira se ele foi para a raiz do deploy.

## Atualizar o conteúdo

Substitua o `pautas.json` e faça o deploy. O `index.html` não muda.

A tarefa mensal automática (dia 20, 9h) já foi apontada para `https://sistema-de-marketing.vercel.app/pautas.json`. Ela confirma as datas dos eventos que mudam a cada edição, acrescenta variações de pauta para as datas de peso alto e amplia o banco de perenes.

## Estrutura do pautas.json

- **`datas`** — 137 registros. Cada um: `id`, `nome`, `tipo` (`fixa` | `pascal` | `nth` | `ultimoDow`), `regiao` (Nacional / RS / PR / Setor), `peso` de 1 a 3. Opcionais: `feriado`, `campanha`, `aprox` (exibe o selo CONFIRMAR) e `prazoDias`, que alimenta o alerta de prazo.
- **`pautas`** — indexado por `id` da data e por marca. Cada marca tem uma **lista**: com duas ou mais variações, a página alterna de um ano para o outro.
- **`perenes`** — peças sem data. Hoje 47 para a Impresul e 40 para a Click. É o que espaça a repetição ao longo do ano.

## O que ainda depende de gente

As datas com selo **CONFIRMAR** mudam a cada edição e a oficial nem sempre saiu: Expointer, Oktoberfest de Santa Cruz, Mercopar, Natal Luz, Feira do Livro de POA, Festuris, Natal de Curitiba, Salão ARP, FuturePrint e os prêmios do setor. O motor usa a data típica até alguém corrigir.

Alguns aniversários de cidade do RS e do PR ficaram fora do registro porque as fontes divergiam sobre a data e sobre ser feriado municipal. Melhor confirmar na prefeitura antes de incluir — um erro aqui se repetiria todo ano.
